package com.clb.io;

import java.io.InputStream;

public class Resources {

    /**
     * 根据配置文件路径加载成字节输入流，存储到内存
     * @param path
     * @return
     */
    public static InputStream getResourceAsSteam(String path) {
        InputStream resourceAsStream = Resources.class.getClassLoader().getResourceAsStream(path);
        return resourceAsStream;
    }


}
