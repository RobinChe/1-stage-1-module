package com.clb.config;

public enum MapperTagEnum {


    INSERT("insert"),
    DELETE("delete"),
    UPDATE("update"),
    SELECT("select");

    private String name;
    private MapperTagEnum(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static MapperTagEnum getMapperTagEnumByName(String name) {
        for (MapperTagEnum tagEnum : MapperTagEnum.values()) {
            if(tagEnum.getName().equals(name))
                return tagEnum;
        }
        return null;
    }
}
