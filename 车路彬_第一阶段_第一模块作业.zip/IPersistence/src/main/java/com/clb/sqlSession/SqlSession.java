package com.clb.sqlSession;

import java.util.List;

public interface SqlSession {

    public <E> List<E> selectList(String statementId, Object... params) throws Exception;



    public <T> T selectOne(String statementId, Object... params) throws Exception;

    // 自定义增加方法
    public Integer insert(String statementId, Object... params) throws Exception;

    // 自定义修改方法
    public Integer update(String statementId, Object... params) throws Exception;

    // 自定义删除方法
    public <E> Integer delete(String statementId, E uid) throws Exception;


    public <T> T getMapper(Class<?> mapperClass);

}
