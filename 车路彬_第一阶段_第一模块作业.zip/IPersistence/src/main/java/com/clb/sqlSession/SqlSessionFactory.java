package com.clb.sqlSession;

public interface SqlSessionFactory {

    public SqlSession openSession();

}
