package com.clb.sqlSession;

import com.clb.pojo.Configuration;
import com.clb.pojo.MappedStatement;

import java.util.List;

public interface Executor {

    public <E> List<E> query(Configuration configuration, MappedStatement mappedStatement, Object... params) throws Exception;

    /**
     * 执行器 -- 添加
     * @param configuration
     * @param mappedStatement
     * @param params
     * @param <E>
     * @return
     * @throws Exception
     */
    public Integer insert(Configuration configuration, MappedStatement mappedStatement, Object... params) throws Exception;

    /**
     * 执行器 -- 修改
     * @param configuration
     * @param mappedStatement
     * @param params
     * @return
     * @throws Exception
     */
    public Integer update(Configuration configuration, MappedStatement mappedStatement, Object... params) throws  Exception;

    /**
     * 执行器 -- 删除
     * @param configuration
     * @param mappedStatement
     * @param uid
     * @param <E>
     * @return
     */
    public <E> Integer delete(Configuration configuration, MappedStatement mappedStatement, E uid) throws Exception;
}
