package com.clb.sqlSession;

import com.clb.config.MapperTagEnum;
import com.clb.pojo.Configuration;
import com.clb.pojo.MappedStatement;

import java.lang.reflect.*;
import java.util.List;


public class DefaultSqlSession implements  SqlSession {

    private Configuration configuration;


    public DefaultSqlSession(Configuration configuration) {
        this.configuration = configuration;
    }

    @Override
    public <E> List<E> selectList(String statementId, Object... params) throws Exception {
        //将要去完成对simpleExecutor里的query方法调用
        SimpleExecutor simpleExecutor = new SimpleExecutor();
        MappedStatement mappedStatement = configuration.getMappedStatementMap().get(statementId);
        List<Object> list = simpleExecutor.query(configuration, mappedStatement, params);

        return (List<E>) list;
    }

    @Override
    public <T> T selectOne(String statementId, Object... params) throws Exception {
        List<Object> objects = this.selectList(statementId, params);
        if(objects != null && objects.size() == 1)
            return (T) objects.get(0);
        else
            throw new RuntimeException("查询结果为空或返回结果过多");
    }

    /**
     * sqlSession insert 实现
     * @param statementId
     * @param params
     * @return
     * @throws Exception
     */
    @Override
    public Integer insert(String statementId, Object... params) throws Exception {
        SimpleExecutor simpleExecutor = new SimpleExecutor();
        MappedStatement mappedStatement = configuration.getMappedStatementMap().get(statementId);
        Integer i = simpleExecutor.insert(configuration, mappedStatement, params);
        return i;
    }

    @Override
    public Integer update(String statementId, Object... params) throws Exception {
        SimpleExecutor simpleExecutor = new SimpleExecutor();
        MappedStatement mappedStatement = configuration.getMappedStatementMap().get(statementId);
        Integer i = simpleExecutor.update(configuration, mappedStatement, params);
        return i;
    }

    @Override
    public <E> Integer delete(String statementId, E uid) throws Exception {
        SimpleExecutor simpleExecutor = new SimpleExecutor();
        MappedStatement mappedStatement = configuration.getMappedStatementMap().get(statementId);
        Integer i = simpleExecutor.delete(configuration, mappedStatement, uid);
        return i;
    }

    @Override
    public <T> T getMapper(Class<?> mapperClass) {

        // 使用JDK动态代理来为Dao接口生成代理对象，并返回
        Object proxyInstance = Proxy.newProxyInstance(DefaultSqlSession.class.getClassLoader(), new Class[]{mapperClass}, new InvocationHandler() {

            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

                // 底层还是执行JDBC代码，根据不同情况来调用selectList 或者 selectOne
                // 参数准备：1.statementid：sql语句的唯一标识：namespace.id=接口权限定名.方法名
                String methodName = method.getName();
                String className = method.getDeclaringClass().getName();

                String statementId = className + "." + methodName;

                MappedStatement mappedStatement = configuration.getMappedStatementMap().get(statementId);

                MapperTagEnum mapperTagEnumByName = MapperTagEnum.getMapperTagEnumByName(mappedStatement.getTagName());
                switch(mapperTagEnumByName) {
                    case SELECT:{
                        // 准备参数：params:args
                        // 获取被调用方法的返回值类型
                        Type genericReturnType = method.getGenericReturnType();
                        /*
                         * Type接口类，是所有类型的公共接口。包括原始类型、参数化类型、数组类型、类型变量和基本类型。
                         * ParameterizedType,TypeVariable,WildCardType,GenericArrayType 这四个接口都是Type的子接口
                         */
                        if(genericReturnType instanceof ParameterizedType) {
                            List<Object> objects = selectList(statementId, args);
                            return objects;
                        }
                        return selectOne(statementId, args);
                    }
                    case INSERT:{
                        System.out.println("进入的insert...");
                        return insert(statementId, args);
                    }
                    case UPDATE:{
                        System.out.println("进入了update...");
                        return update(statementId, args);
                    }
                    case DELETE:{
                        System.out.println("进入了delete...");
                        Object uid = args[0];
                        return delete(statementId, uid);
                    }
                }
                return null;
            }
        });
        return (T) proxyInstance;
    }
}
