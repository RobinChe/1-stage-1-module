package com.clb.sqlSession;

import java.lang.reflect.Method;
import java.lang.reflect.Type;

public class MethodRefactTest {

    public static void main(String[] args) {
        Method[] methods = SampleClass.class.getMethods();
        Type returnType = methods[0].getGenericReturnType();
        System.out.println(returnType.getTypeName());
//        if(returnType instanceof ) {
//            System.out.println("=============");
//        }
    }
}

class SampleClass {
    private String sampleField;

    public int getAge() {
        return 10;
    }

    public String getSampleField() {
        return sampleField;
    }

    public void setSampleField(String sampleField) {
        this.sampleField = sampleField;
    }
}