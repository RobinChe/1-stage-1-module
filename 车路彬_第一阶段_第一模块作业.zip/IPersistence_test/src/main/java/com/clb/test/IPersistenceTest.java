package com.clb.test;

import com.clb.dao.IUserDao;
import com.clb.io.Resources;
import com.clb.pojo.User;
import com.clb.sqlSession.SqlSession;
import com.clb.sqlSession.SqlSessionFactory;
import com.clb.sqlSession.SqlSessionFactoryBuilder;
import org.dom4j.DocumentException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.beans.PropertyVetoException;
import java.io.InputStream;

public class IPersistenceTest {

    private SqlSession sqlSession;

    @Before
    public void before() throws Exception {
        InputStream resourceAsSteam = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().builder(resourceAsSteam);
        sqlSession = sqlSessionFactory.openSession();
    }


    @Test
    public void testQuery() throws Exception {

        // 两种实现方式
        //调用
        User user = new User();
        user.setId(1);
        user.setUsername("张三");
//        User user1 = sqlSession.selectOne("com.clb.dao.IUserDao.findByCondition", user);
//        System.out.println(user1);

        // mapper使用动态代理实现
        IUserDao userDao = sqlSession.getMapper(IUserDao.class);
        User user2 = userDao.findByCondition(user);
        System.out.println(user2);

    }


    /**
     * 测试增加
     * @throws Exception
     */
    @Test
    public void testInsert() throws Exception {
        //调用
        User user = new User();
        user.setId(3);
        user.setUsername("王五");
//        int count = sqlSession.insert("com.clb.dao.IUserDao.insert", user);
//        System.out.println(count);
//        Assert.assertTrue(count == 1);



        // mapper使用动态代理实现
        IUserDao userDao = sqlSession.getMapper(IUserDao.class);
        int count2 = userDao.insert(user);
        System.out.println(count2);
        Assert.assertTrue(count2 == 1);

    }

    /**
     * 测试修改
     * @throws Exception
     */
    @Test
    public void testUpdate() throws Exception {
        //调用
        User user = new User();
        user.setId(3);
        user.setUsername("王qi");
//        int count = sqlSession.update("com.clb.dao.IUserDao.update", user);
//        System.out.println(count);
//        Assert.assertTrue(count == 1);



        // mapper使用动态代理实现
        IUserDao userDao = sqlSession.getMapper(IUserDao.class);
        int count2 = userDao.update(user);
        System.out.println(count2);
        Assert.assertTrue(count2 == 1);

    }


    /**
     * 测试删除
     * @throws Exception
     */
    @Test
    public void testDelete() throws Exception {
        //调用
        int uid = 3;
//        int count = sqlSession.delete("com.clb.dao.IUserDao.delete", uid);
//        System.out.println(count);
//        Assert.assertTrue(count == 1);



        // mapper使用动态代理实现
        IUserDao userDao = sqlSession.getMapper(IUserDao.class);
        int count2 = userDao.delete(uid);
        System.out.println(count2);
        Assert.assertTrue(count2 == 1);

    }




}
