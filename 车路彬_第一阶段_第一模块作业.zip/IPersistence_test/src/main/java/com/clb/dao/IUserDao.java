package com.clb.dao;

import com.clb.pojo.User;

import java.util.List;

public interface IUserDao {


    public List<User> findAll() throws Exception;


    public User findByCondition(User user) throws Exception;


    /**
     * 新增用户
     * @param user
     * @return
     * @throws Exception
     */
    public int insert(User user) throws Exception;


    /**
     * 修改用户信息
     * @param user
     * @return
     * @throws Exception
     */
    public int update(User user) throws Exception;


    /**
     * 删除用户
     * @param uid
     * @return
     * @throws Exception
     */
    public int delete(Integer uid) throws  Exception;

}
